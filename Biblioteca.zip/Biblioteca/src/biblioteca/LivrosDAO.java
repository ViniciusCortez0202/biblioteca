/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package biblioteca;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Rocha
 */
public class LivrosDAO implements Conexoes {

    PreparedStatement n = null;

    @Override
    public void add(Livros l) {

        String sql = "INSERT INTO livros (titulo, autor, area, editora) VALUES (?, ?, ?, ?)";

        try {
            n = Conectar.getConexao().prepareStatement(sql);

            n.setString(1, l.getTitulo());
            n.setString(2, l.getAutor());
            n.setString(3, l.getArea());
            n.setString(4, l.getEditora());

            n.execute();
            n.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Não foi possivel adicionar um "
                    + "novo livro banco de dados", "Atenção!", 2);
        }

    }

    @Override
    public ArrayList selecionar() {

        ArrayList<Livros> livros = new ArrayList();

        String sql = "SELECT titulo, autor, area, editora FROM livros";

        try {
            n = Conectar.getConexao().prepareStatement(sql);
            ResultSet rs = n.executeQuery();

            while (rs.next()) {
                livros.add(new Livros(rs.getString("titulo"), rs.getString("autor"),
                        rs.getString("area"), rs.getString("editora")));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao tentar procurar livros!", "Atenção!", 2);
        }
        return livros;
    }

}
